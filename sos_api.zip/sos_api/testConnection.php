<?php

require_once './pdo/data_connection.php';

echo "HOSTNAME: " . HOSTNAME .
 " PORT: " . PORT . 
 " USERNAME: " . USERNAME . 
 " PASSWORD: " . PASSWORD . 
 " DBNAME: " . DBNAME;

?>
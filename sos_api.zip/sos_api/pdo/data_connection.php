<?php

// define("HOSTNAME", "192.168.2.210");
// define("PORT", "3306");
// define("USERNAME", "root");
// define("PASSWORD", "kkD%IreqErjV");
// define("DBNAME", "SOS");

//IF USES DOCKER, USE IP OF DOCKER HERE
define("HOSTNAME", "172.17.0.3");

define("PORT", "3306");
define("USERNAME", "sos");
define("PASSWORD", "2MdHUIVJC*t-0Mz/");
define("DBNAME", "SOS");

//CHANGE THIS PARAMETER USING THE IP LIKE : 192.168.2.210 OR 189.234.50.21
define("EXTERNAL_IP", "18.234.231.190")


?>

<?php
    require_once(dirname(__FILE__) . '/../cors/cors.php');
    require_once(dirname(__FILE__) . '/../pdo/Sql.php');

    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);
    
    $categoria = $request->categoria;
    $categoria = strtoupper($categoria);

    $query = "INSERT INTO categoria_equipamentos (categoria) VALUES (:categoria)";

    try {
        $mariadb = new Sql();
        $result = $mariadb->Sqlquery($query, [
            ":categoria" => $categoria
        ]);
    } catch(PDOException $e){
        throw new Error($e->getMessage(), (int) $e->getCode());
    }

    echo json_encode($result);
    exit;
?>
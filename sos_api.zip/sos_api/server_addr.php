<?php

echo getHostByName(php_uname('n'))

?>